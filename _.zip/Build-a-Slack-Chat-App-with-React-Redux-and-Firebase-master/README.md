## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/build-a-slack-chat-app-with-react-redux-and-firebase-video/9781839219030)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Build-a-Slack-Chat-App-with-React-Redux-and-Firebase
Code Repository for Build a Slack Chat App with React, Redux, and Firebase, Published by Packt
